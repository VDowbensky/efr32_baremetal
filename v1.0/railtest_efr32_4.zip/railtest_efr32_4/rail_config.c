// Copyright 2021 Silicon Laboratories, Inc.
//
//

/***************************************************************************//**
 * @brief RAIL Configuration
 * @details
 *   WARNING: Auto-Generated Radio Config  -  DO NOT EDIT
 *   Radio Configurator Version: 5.6.0
 *   RAIL Adapter Version: 2.4.13
 *   RAIL Compatibility: 1.x
 *******************************************************************************
 * # License
 * <b>Copyright 2019 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Zlib
 *
 * The licensor of this software is Silicon Laboratories Inc.
 *
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 ******************************************************************************/
#include "em_device.h"
#include "rail_config.h"

const uint32_t generated_phyInfo[] = {
  0UL,
  0x00200000UL, // 32.0
};

const uint32_t generated[] = {
  0x01010FF0UL, (uint32_t) &generated_phyInfo,
  0x01010FF4UL, 0x00000000UL,
  0x01010FF8UL, 0x0003C000UL,
  0x01010FFCUL, 0x0003C002UL,
  0x00010004UL, 0x00000000UL,
  0x00010008UL, 0x00000000UL,
  0x00010018UL, 0x0000000FUL,
  0x0001001CUL, 0x00000000UL,
  0x00010028UL, 0x00000000UL,
  0x0001002CUL, 0x00000108UL,
  0x00010030UL, 0x0000FFFFUL,
  0x00010034UL, 0x00000001UL,
  0x00010038UL, 0x00000000UL,
  0x0001003CUL, 0x00000000UL,
  0x00010040UL, 0x00000700UL,
  0x00010048UL, 0x00000000UL,
  0x00010054UL, 0x00000000UL,
  0x00010058UL, 0x00000000UL,
  0x000100A0UL, 0x00000CFFUL,
  0x000100A4UL, 0x00000000UL,
  0x000100A8UL, 0x00000DFFUL,
  0x000100ACUL, 0x00000000UL,
  0x00012000UL, 0x00000744UL,
  0x00012010UL, 0x00000000UL,
  0x00012018UL, 0x0000A001UL,
  0x00013008UL, 0x0000AC3FUL,
  0x00013030UL, 0x00104000UL,
  0x00013034UL, 0x00000003UL,
  0x00013040UL, 0x00000000UL,
  0x000140A0UL, 0x0F00277AUL,
  0x000140F4UL, 0x00001020UL,
  0x00014134UL, 0x00000880UL,
  0x00014138UL, 0x000087F6UL,
  0x00014140UL, 0x008800E0UL,
  0x00014144UL, 0x1153E6C1UL,
  0x00016014UL, 0x00000010UL,
  0x00016018UL, 0x04000000UL,
  0x0001601CUL, 0x0001400FUL,
  0x00016020UL, 0x00002000UL,
  0x00016024UL, 0x00000000UL,
  0x00016028UL, 0x03000000UL,
  0x0001602CUL, 0x00000000UL,
  0x00016030UL, 0x00FF2FD0UL,
  0x00016034UL, 0x00000820UL,
  0x00016038UL, 0x02020078UL,
  0x0001603CUL, 0x00140012UL,
  0x00016040UL, 0x0000B16FUL,
  0x00016044UL, 0x00000000UL,
  0x00016048UL, 0x0220081FUL,
  0x0001604CUL, 0x00000000UL,
  0x00016050UL, 0x002303B0UL,
  0x00016054UL, 0x00000000UL,
  0x00016058UL, 0x00000000UL,
  0x0001605CUL, 0x22140A04UL,
  0x00016060UL, 0x504B4133UL,
  0x00016064UL, 0x00000000UL,
  0x00017014UL, 0x000270F8UL,
  0x00017018UL, 0x00000300UL,
  0x0001701CUL, 0x82710060UL,
  0x00017028UL, 0x00000000UL,
  0x00017048UL, 0x0000383EUL,
  0x0001704CUL, 0x000025BCUL,
  0x00017070UL, 0x00020105UL,
  0x00017074UL, 0x00000113UL,
  0x00017078UL, 0x006D8480UL,

  0xFFFFFFFFUL,
};

const uint32_t *configList[] = {
  generated,
};

const char *configNames[] = {
  "generated",
};

RAIL_ChannelConfigEntry_t generated_channels[] = {
  { 0, 20, 100000, 868000000 },
};

const RAIL_ChannelConfig_t generated_channelConfig = {
  generated_channels,
  1,
};

const RAIL_ChannelConfig_t *channelConfigs[] = {
  &generated_channelConfig,
};

RAIL_FrameType_t *frameTypeConfigList[] = {
  NULL
};

const uint8_t irCalConfig[] = {
  25, 69, 3, 6, 4, 16, 1, 1, 1, 3, 1, 6, 0, 16, 39, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0
};


//        _  _                          
//       | )/ )         Wireless        
//    \\ |//,' __       Application     
//    (")(_)-"()))=-    Software        
//       (\\            Platform        
